var milsec=0, sec=0, min=0;
var h1=document.getElementById("timer")
  start=document.getElementById("start"), stop=document.getElementById("stop"), reset=document.getElementById("reset");
var interval=1;
function count(){
  interval=1;
  milsec+=interval;
  if (milsec>=100){
    milsec=0;
    sec+=interval;
  }
  if (sec>=60){
    sec=0;
    min+=interval;
  }

  // h1.textContent = (minutes ? (minutes > 9 ? minutes : "0" + minutes) : "00") + ":" + (seconds ? (seconds > 9 ? seconds : "0" + seconds) : "00") + ":" + (milli_seconds > 9 ? milli_seconds : "0" + milli_seconds);
  
  h1.textContent=(min?(min>9?min:"0"+min):"00")+":"+(sec?(sec>9?sec:"0"+sec):"00")+":"+(milsec>9?milsec:"0"+milsec);
  timer()
}
function timer(){
  t=setTimeout(count,10)
}
start.onclick=count;
stop.onclick=function(){
  clearTimeout(t)
}
reset.onclick=function(){
  h1.textContent="00 : 00 : 00";
  sec=0;
  milsec=0;
  min=0;
  interval=0;
}
