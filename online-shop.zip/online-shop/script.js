var menubtn=document.getElementById("menubtn")
var togel=document.getElementById("togel")
var menu=document.getElementById("menu")

togel.style.right="-250px";
menubtn.onclick=function(){
  console.log("clicked")
  if (togel.style.right=="-250px"){
    togel.style.right=="0px";
    console.log("cli")
  }
  else {
    togel.style.right=="-250px";
  }
}

function openImg(element){
  window.open(element.src);
}