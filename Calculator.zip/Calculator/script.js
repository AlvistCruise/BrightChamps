function load(){
  console.log('tes');
  var btn=document.querySelectorAll("#kalkulator span");
  var operator=['+','-','x','/'];
  var screen=document.querySelector("#screen");
  console.log(screen)
  var btnvalue;
  var input;
  for(var i=0; i<btn.length; i++){
    var decimaladd=false;
    btn[i].addEventListener('click',function(){
      btnvalue=this.innerHTML;
      input=screen.innerHTML;
      switch(btnvalue){
        case 'C':
          screen.innerHTML='';
          decimaladd=false;
          break;
        case '=':
          var lastChar=input[input.length-1];
          input=input.replace('x','*');
          if (operator.includes(lastChar)|| lastChar=='.'){
            break;
          }
          else{
            screen.innerHTML=eval(input);
          }
          decimaladd=false;
          break;
        case '.':
          if(!decimaladd){
            screen.innerHTML+=btnvalue;
            decimaladd=true;
            
          }
          break;
        case '+':
          
        case '-':
          
        case 'x':
        case '/':
          var lastChar=input[input.length-1];
          if(input!=''&&!operator.includes(lastChar)){
            screen.innerHTML+=btnvalue;
          }
          else{
            if(input==''&&btnvalue=='-'){
              screen.innerHTML+=btnvalue;
            }
          }
          if(operator.includes(lastChar)&&input.length>1){
            screen.innerHTML=input.replace(lastChar,btnvalue);
          }
          break;
        default:
          screen.innerHTML+=btnvalue;
          break;
      }
    });
  }
}